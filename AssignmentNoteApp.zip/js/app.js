var app=angular.module("noteApp",["ngRoute"]);
app.config(function($routeProvider)
		{
	$routeProvider
		.when("/login",{
		templateUrl:"pages/login.html",
		controller:"loginCtrl"
	})
	.when("/signUp",{
		templateUrl:"pages/signUp.html",
		controller:"signUpCtrl"
	})
	.when("/addNote",{
		templateUrl:"pages/add.html",
		controller:"dashboardCtrl"
	})
	.when("/viewNote",{
		templateUrl:"pages/view.html",
		controller:"modificationCtrl"
	})
	.when("/update",{
		templateUrl:"pages/update.html",
		controller:"updateCtrl"
	});

		});