
app.controller("loginCtrl",function($scope,$http,$location,$rootScope){
	
	console.log("in login controller");
	$rootScope.isLogin="true";
	$rootScope.isDashboard="false";
	$scope.login={};
	$scope.checkLogin=function()
	{
		$http.get("./json/login.json")
		.success(function(data)
		{
			
			console.log(data);
			//-------for checking user from predefined json having dummy data
			if($scope.login.username==data.username && $scope.login.password==data.password)
				{
				alert("Successfully Logged In");
				$location.path("/dashboard");
				}
			//------- for checking credentials for newly created users
			else
				{
				
				angular.forEach($rootScope.users,function(value)
						{
					console.log(value);
					if($scope.login.username==value.username && $scope.login.password==value.password)
					{
					alert("Successfully Logged In");
					$location.path("/dashboard");
					}
				else
					{
					alert("Wrong Credentials");
					$location.path("/login");
					}
						})
				
				}
			
			
		})	
		.error(function()
		{
			console.log("some error occurred");
		});
			
	};
	
	
});

app.controller("signUpCtrl",function($scope,$rootScope){
	
	
	console.log	("in sign up controller");
	$rootScope.newUser={};
	$rootScope.users=[];
	$scope.signUp=function()
	{
		$rootScope.users.push($scope.newUser);
		console.log($rootScope.users);
		alert("User added successfully!!");
	}
	
	
});

//----- have created different controllers for different scenarios of add, delete etc. because in routing 
//---- i am doing routing for different functionalities
//-- other way is we can use service for the same and inject in all controllers
// or else if we have to use rootscope only then we cannot use routing we have to handle each functionality with hide and show

app.controller("dashboardCtrl",function($scope,$rootScope){
	
	console.log("dashboard ctrl");
	$rootScope.notes=[{"title":"Mail","description":"Send mail to customer"}];
	$scope.note={};
	
	$scope.addNote=function(note)
	{
		$rootScope.notes.push(note);
		console.log($rootScope.notes);
		$scope.note={};
		alert("Note added successfully!!");
	};
	
	
	
});
app.controller("modificationCtrl",function($scope,$rootScope,$location){
	console.log($rootScope.notes);
	
	$scope.deleteNote=function(index)
	{
		console.log("in delete function");
		console.log($rootScope.notes);
		console.log(index);
		$rootScope.notes.splice(index,1);
		console.log($rootScope.notes);
		alert("Note deleted successfully!!");
		
	};
	
	$scope.updateNote=function(index)
	{
		$rootScope.updateNote={};
		$rootScope.updateNote=$rootScope.notes[index];
		$rootScope.indexToBeUpdated=index;
		$location.path("/update");
	};
	
});
	
	app.controller("updateCtrl",function($scope,$rootScope,$location){
		
	$scope.updateValues=function(updatedNote)
	{
		$rootScope.notes[$rootScope.indexToBeUpdated]=updatedNote;
		console.log($rootScope.notes)
		alert("Note Updated successfully!!");
		$location.path("/viewNote");
	}
});


